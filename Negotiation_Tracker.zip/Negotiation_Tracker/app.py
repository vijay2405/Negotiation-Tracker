from flask import Flask, render_template, request
import pyodbc
from google.cloud import speech
from dB.dat_credential import DatCredential
from google.cloud import storage
client = storage.Client()
bucket = client.get_bucket('gdw-team-ww-smai-business-default')

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    transcript = ""
    if request.method == "GET":
        username = request.args.get('username')
        date = request.args.get('date')
        
    if request.method == "POST":
        if 1:
            
            name = request.form['inputName']
            customer = request.form['inputPhone']
            Desc = request.form['inputMessage']
            Title = request.form['inputSubject']
            date = request.form['inputEmail']
            DS = request.form['inputMessageD']
            SS = request.form['inputMessageS']
            PS = request.form['inputMessageP']
            IS = request.form['inputMessageI']
            if customer and Desc:
              print("FORM DATA RECEIVED")
              add_data(name,customer,Desc,Title,date,DS,SS,PS,IS)              
              return '<html><h1 style="text-align:center;color:#0090da">Your Message has been received & processed. You can now successfully close this page</h1></html>'
            else:
              return '<html><h1 style="text-align:center;>Please fill all the details</h1></html>'

    return render_template('index.html',username=username,date=date)

def add_data(name,customer,Desc,Title,date,DS,SS,PS,IS):
    sts, cnxn = conn_start()
    if sts == "success":
        insert_query1 = "insert into [SALES].[dbo].[TRANSCRIPT_DETAILS_TEMP] (CUSTOMER,TITLE,USERNAME,DATE,SUMMARY,DEMAND_SUMMARY,SUPPLY_SUMMARY,PRICING_SUMMARY,INVENTORY_SUMMARY) values (?,?,?,?,?,?,?,?,?)"
        cursor = cnxn.cursor()
        cursor.execute(insert_query1,customer,Title,name,date,Desc,DS,SS,PS,IS)
        cnxn.commit()
        cursor.close()
    return 'Success'

@app.route("/send",methods=['GET','POST'])
def send():
    transcript = ""
    if request.method == "POST":
       print('got request')
       f = open('./file.wav', 'wb')
       f.write(request.data)
       f.close()
       if 1:
        blob_name = "file.wav"
        blob = bucket.blob(blob_name)
        source_file_name = "file.wav"
        blob.upload_from_filename(source_file_name)
        client1 = speech.SpeechClient()
        gcs_uri = 'gs://gdw-team-ww-smai-business-default/file.wav'
        audio = speech.RecognitionAudio(uri=gcs_uri)
        config = speech.RecognitionConfig(language_code="en-US")    
        operation = client1.long_running_recognize(config=config, audio=audio)
        print("Waiting for operation to complete...")
        response = operation.result(timeout=120)
          #transcript = response.results.alternatives[0].transcript
# Each result is for a consecutive portion of the audio. Iterate through
# them to get the transcripts for the entire audio file.
        for result in response.results:
         transcript = transcript + result.alternatives[0].transcript
            # The first alternative is the most likely one for this portion.
#             print(u"Transcript: {}".format(result.alternatives[0].transcript))
#             print("Confidence: {}".format(result.alternatives[0].confidence))

    #print((transcript))
    return(transcript)
    

    
    


def conn_start():
    server = "SIWSQL268.SING.MICRON.COM\SIMSSPROD506"
    port_number=52432
    driver= '{ODBC Driver 17 for SQL Server}'
    site_name = "SINGAPORE"
    system_name = "EDW ETL Control"
    version_name = "EDS"
    credential_name = "EDSLOADER"
    environment_name = "Production"
    dat = DatCredential(site_name=site_name, system_name=system_name, version_name=version_name, credential_name=credential_name, environment_name=environment_name)
    creds = dat.get_credentials()
    database = "EDS"
    username = "EDSLOADER"
    password = creds["Password"]
    # connection uri
    connection_uri = ('DRIVER='+driver+';\
                    SERVER='+server+';\
                    PORT=port_number;\
                    DATABASE='+database+';\
                    UID='+username+';\
                    PWD='+ password)
    # create connection
    try:
        cnxn_506 = pyodbc.connect(connection_uri)
        print("success")
        return "success", cnxn_506
    except pyodbc.Error as ex:
        sqlstate1 = ex.args[0]
        sqlstate2 = ex.args[1]
        print("--+>", sqlstate1, sqlstate2)
        return "failed", None
#     driver= '{ODBC Driver 17 for SQL Server}'
#     database = "SALES"
#     password = "S@nt1aCruZ"
#     username = "EDSLOADER"
#     server = "SIWSQL268.SING.MICRON.COM\SIMSSPROD506"
#     port_number=52432
#     connection_uri = ('DRIVER='+driver+';\
#                        SERVER='+server+';\
#                        PORT=port_number;\
#                        DATABASE='+database+';\
#                        UID='+username+';\
#                        PWD='+ password)
    
#     try:
#         cnxn_506 = pyodbc.connect(connection_uri)
#         print("success")
#         return "success", cnxn_506
#     except pyodbc.Error as ex:
#         sqlstate1 = ex.args[0]
#         sqlstate2 = ex.args[1]
#         print("--+>", sqlstate1, sqlstate2)
#         return "fail", None
        
        
if __name__ == "__main__":
    app.run(host ="10.8.4.185",debug=True,port = 5050, threaded=True,ssl_context=('cert.pem', 'key.pem'))