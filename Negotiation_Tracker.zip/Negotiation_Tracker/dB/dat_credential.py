import requests
import json


class DatCredential:
    """
    Author: Sourabh Mehta (sourabhmehta@micron.com)
    Team: SMAI_DS_ADMINS
    Revision Date: 07/05/2021

    A simple credential class that retreives DAT credentials from the api gateway
    """

    def __init__(self, site_name, system_name, version_name, credential_name, environment_name, dat_secret_key = '\'\'', port = '', refresh_cache = "false"):
        self.api_gw_url = "http://dat-cache-route-dat-proxy-cache.bo-ose-prod.micron.com/dat"
        self.app_accept = 'application/json'
        self.dat_secret_key = dat_secret_key

        self.site = site_name
        self.environment = environment_name
        self.encryptKey = dat_secret_key
        self.system = system_name
        self.version = version_name
        self.service = credential_name
        self.refresh = refresh_cache


    def get_credentials(self):
        my_headers = {
            'Content-Type': self.app_accept
        }
        my_parameters = {
            'site': self.site,
            'environment': self.environment,
            'service': self.service,
            'system': self.system,
            'version': self.version,
            'refresh_cache': self.refresh,
            'encrypt_key': self.encryptKey
        }
        response = requests.post(self.api_gw_url, json=my_parameters, headers= my_headers)
        
        return json.loads(response.text)

