Terminal 1
port 5050